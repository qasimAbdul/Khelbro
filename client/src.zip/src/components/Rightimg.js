import React from 'react'
import "./style/style.css"
const Rightimg = () => {
  return (
    <>
        <div className="right_img"></div>
    </>
  )
}

export default Rightimg