import React from 'react'

const Error = () => {
  return (
    <div style={{marginTop:"2rem"}}>
        <h1 style={{fontSize:"5rem"}}>Error</h1>
    </div>
  )
}

export default Error