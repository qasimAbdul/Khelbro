import React from 'react'
import "./style/content.css"
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

const Content = () => {
  return (
    <>
    
      <div className="inputBox" style={{ width: "30.8rem", }}>
        <div className="box1" >
          How to win money?
        
        <div className="video_help">VIDEO HELP</div>
        </div>
      </div>
      <div className="inputBox1" style={{ padding: "1rem 0.8rem 0.5rem 0" }}>
        <Stack sx={{ width: '93%' }} spacing={2}>

          <Alert severity="warning" style={{ fontSize: "0.71rem", fontWeight: "500", padding: "0.6rem 1rem", color: "#2c2c2c", }}>Notice: KhelBro does not charge a <b>28% GST</b> on deposits. To learn more,<br />
            <span>click here.</span>
          </Alert>
        </Stack>
      </div>
      <div className="our_game">
        Our Games
      </div>
      <div className="game_section ">
        <img className="img_1" src="./global-purple-battleIcon.png" alt="" /><span>is for Battles and</span>
        <img className="img_2" src="./global-blue-tournamentIcon.png" alt="" /><span className='trn'>is for Tournaments. <b>Know more here.</b></span>

      </div>

      {/* Cards */}

      {/* card_1 */}
      <div className="game_cards">
      <Card style={{ width: '13rem'}}>
      <Card.Img variant="top" src="./mortalkombat1-1684430065700.jpg" style={{height:"10.5rem"}}/>
      <Card.Body>
        <img src="./global-purple-battleIcon.png" alt="" style={{width:"1.25rem", position:"absolute", top:"9.8rem", left:"5.8rem"}}/>
        <Card.Title className='title'>Mortal Kombat</Card.Title>
      </Card.Body>
    </Card>

    {/* card_2 */}
    <Card style={{ width: '13rem'}}>
      <Card.Img variant="top" src="./mortalkombat1-1684430065700.jpg" style={{height:"10.5rem"}}/>
      <Card.Body>
        <img src="./global-purple-battleIcon.png" alt="" style={{width:"1.25rem", position:"absolute", top:"9.8rem", left:"5.8rem"}}/>
        <Card.Title className='title'>Mortal Kombat</Card.Title>
      </Card.Body>
    </Card>

    {/* card_3 */}
    <Card style={{ width: '13rem', marginTop:"2rem"}}>
      <Card.Img variant="top" src="./mortalkombat1-1684430065700.jpg" style={{height:"10.5rem"}}/>
      <Card.Body>
        <img src="./global-purple-battleIcon.png" alt="" style={{width:"1.25rem", position:"absolute", top:"9.8rem", left:"5.8rem"}}/>
        <Card.Title className='title'>Mortal Kombat</Card.Title>
      </Card.Body>
    </Card>

    {/* card_4 */}
    <Card style={{ width: '13rem',marginTop:"2rem"}}>
      <Card.Img variant="top" src="./mortalkombat1-1684430065700.jpg" style={{height:"10.5rem"}}/>
      <Card.Body>
        <img src="./global-purple-battleIcon.png" alt="" style={{width:"1.25rem", position:"absolute", top:"9.8rem", left:"5.8rem"}}/>
        <Card.Title className='title'>Mortal Kombat</Card.Title>
      </Card.Body>
    </Card>
      </div>


    </>
  )
}

export default Content