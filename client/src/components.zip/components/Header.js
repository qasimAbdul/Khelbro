import React from 'react'
// import Nav from 'react-bootstrap/Nav';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { NavLink } from 'react-router-dom';
import "./style/style.css"

const Header = () => {
  return (
    <>
    
    <div >
      <div className="left" style={{width:"30.8rem", position:"fixed",top:"0",left:"0rem", zIndex:"2"}}>
      <Navbar bg="white" data-bs-theme="light" style={{height:"4rem",boxShadow:"0 0.3rem 0.4rem 0rem rgba(0,0,0,.06)",}}>
        <Container>
          
          <Nav className="me-auto " >
            <Nav.Link href="#home">
              <img src="./khelbro.png" alt="" style={{width:"2.3rem"}}/>
            </Nav.Link>

            <div className="signup_login">
           <Nav.Link >
           <NavLink to='/login'>  <button className='signup'>SIGNUP</button></NavLink>
            </Nav.Link> 
            <Nav.Link>
            <button className='login'>LOGIN</button>
            </Nav.Link>
            </div>
          </Nav>
        </Container>
      </Navbar>
      </div>
      <div className="right"></div>
    </div>
    <div className="right_img"></div>
      

     
    </>

  )
}

export default Header